@include('includes/adminheader')
@include('includes/adminheadbar')
@include('includes/adminsidebar')

@yield('content')

@include('includes/adminfooter')
