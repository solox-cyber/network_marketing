@include('includes/header')
@include('includes/headbar')
@include('includes/sidebar')

@yield('content')

@include('includes/footer')
