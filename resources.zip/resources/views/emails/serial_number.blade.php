<!DOCTYPE html>
<html>
<head>
    <title>Serial Number Notification</title>
</head>
<body>
    <h2>Serial Number Notification</h2>
    <p>Dear {{ $name }},</p>
    <p>Your serial number is: {{ $serialNumber }}</p>
    <p>Thank you for registering.</p>
</body>
</html>
