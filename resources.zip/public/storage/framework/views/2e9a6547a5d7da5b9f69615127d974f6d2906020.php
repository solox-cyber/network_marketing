<!DOCTYPE html>
<html>
<head>
    <title>Serial Number Notification</title>
</head>
<body>
    <h2>Serial Number Notification</h2>
    <p>Dear <?php echo e($name); ?>,</p>
    <p>Your serial number is: <?php echo e($serialNumber); ?></p>
    <p>Thank you for registering.</p>
</body>
</html>
<?php /**PATH C:\Users\USER\Documents\basic\resources\views/emails/serial_number.blade.php ENDPATH**/ ?>